<?php
# 同步返回页面
# Required File Includes
include("../../../init.php");
include("../../../includes/functions.php");
include("../../../includes/gatewayfunctions.php");
include("../../../includes/invoicefunctions.php");
include("../epay.php");


$gatewaymodule = "epay";
$GATEWAY = getGatewayVariables($gatewaymodule);

$url			= $GATEWAY['systemurl'];
$companyname 	= $GATEWAY['companyname'];
$currency		= $GATEWAY['currency'];

if (!$GATEWAY["type"]) die("Module Not Activated"); 

$gatewayPID 			= $GATEWAY['pid'];
$gatewaySELLER_KEY   	= $GATEWAY['key'];
$epay = new Epay(array(),$gatewayPID,$gatewaySELLER_KEY);


$Notify = $epay->getSignVeryfy($_GET,$_GET['sign']);
if($Notify) {//验证成功
	if($_GET['trade_status']=='TRADE_SUCCESS'){
			
			# Get Returned Variables
			$status = $_GET['trade_status'];
			$invoiceid = $_GET['out_trade_no']; //获取传递过来的订单号
			$transid = $_GET['trade_no'];       //获取传递过来的交易号
			$amount = $_GET['money'];       //获取传递过来的总价格
			$fee = 0;

			$paidcurrency = "CNY";
			$result = select_query( 'tblcurrencies', '', array( 'code' => $paidcurrency ));
			$data = mysql_fetch_array($result);
			$paidcurrencyid = $data['id'];

			$invoiceid = checkCbInvoiceID($invoiceid,$GATEWAY["name"]);
			$result = select_query( 'tblinvoices', '', array( 'id' => $invoiceid ) );
			$data = mysql_fetch_array( $result );
			$userid = $data['userid'];
			$currency = getCurrency( $userid );
			$amount = convertCurrency( $amount, $paidcurrencyid, $currency['id'] );
			checkCbTransID($transid);
			addInvoicePayment($invoiceid,$transid,$amount,$fee,$gatewaymodule);
			logTransaction($GATEWAY["name"],$_GET,"Successful-A");
			echo 'success';
	}else{
		logTransaction($GATEWAY["name"],$_GET,"Unsuccessful");
		echo "fail";//请不要修改或删除
	}
}else {
   echo "fail";//请不要修改或删除
}
?>