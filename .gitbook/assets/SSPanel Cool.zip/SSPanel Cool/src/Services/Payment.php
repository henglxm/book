<?php

namespace App\Services;

use App\Services\Gateway\{
    AopF2F,
    Codepay,
    PaymentWall,
    SPay,
    PAYJS,
    YftPay,
    BitPay,
    BitPayX,
    F2Fpay_PAYJS, 
    StripePay,
    Payssion,
    epay,
    PayBeaver,
    MGate,
    payfament,
    PolicePay,
    THeadPay,
    CoolPay
};

class Payment
{
    public static function getClient()
    {
        $method = $_ENV['payment_system'];
        switch ($method) {
            case ('codepay'):
                return new Codepay();
            case ('paymentwall'):
                return new PaymentWall();
            case ('spay'):
                return new SPay();
            case ('f2fpay'):
                return new AopF2F();
            case ('payjs'):
                return new PAYJS($_ENV['payjs_key']);
            case ('yftpay'):
                return new YftPay();
            case ('bitpay'):
                return new BitPay($_ENV['bitpay_secret']);
            case ('bitpayx'):
                return new BitPayX($_ENV['bitpay_secret']);
            case ('f2fpay_payjs'):
                return new F2Fpay_PAYJS();
            case ('stripe'):
                return new StripePay();
            case ('payssion'):
                return new Payssion();
	        case ("epay"):
                return new epay();
            case ('paybeaver'):
                return new PayBeaver();
            case ('mgate'):
                return new MGate();
            case("policepay"):
                return new PolicePay();
            case("payfament"):
                return new payfament();
            case ('theadpay'):
                return new THeadPay();
            case("cool"):
                return new CoolPay(); 
            default:
                return null;
        }
    }

    public static function notify($request, $response, $args)
    {
        return self::getClient()->notify($request, $response, $args);
    }

    public static function returnHTML($request, $response, $args)
    {
        return self::getClient()->getReturnHTML($request, $response, $args);
    }

    public static function purchaseHTML()
    {
        if (self::getClient() != null) {
            return self::getClient()->getPurchaseHTML();
        }

        return '';
    }

    public static function getStatus($request, $response, $args)
    {
        return self::getClient()->getStatus($request, $response, $args);
    }

    public static function purchase($request, $response, $args)
    {
        return self::getClient()->purchase($request, $response, $args);
    }
}
